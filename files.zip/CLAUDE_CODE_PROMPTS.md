# Claude Code Task Prompts for Valley Clean Team SEO Plan

Copy these prompts directly into Claude Code to execute each task.

---

## PHASE 0: Foundation Fix (Week 1)

### Prompt 1: GBP Post Content Generation
```
Generate 4 weeks of Google Business Profile posts for The Valley Clean Team cleaning service. Each post should be 100-150 words, include a photo suggestion, and end with a CTA. 

Topics:
- Week 1: Winter deep cleaning tips for Shoals homeowners
- Week 2: Move-out cleaning special offer
- Week 3: Team spotlight (veteran-owned, women-led)
- Week 4: Customer testimonial feature

Use casual, helpful tone. Format as markdown with clear headers for each week.
Save as /docs/gbp-posts-january.md
```

### Prompt 2: Citation Tracking Spreadsheet
```
Create an Excel spreadsheet for citation tracking with these columns:
- Directory Name
- URL of Listing
- Date Created
- NAP Matches GBP (Y/N)
- Status (Claimed/Pending/Needs Update)
- Login Email Used
- Notes

Pre-populate with these directories (leave URL and other fields blank for Todd to fill):
1. Google Business Profile
2. Yelp
3. Facebook
4. Bing Places
5. Apple Maps
6. BBB
7. Angi
8. HomeAdvisor
9. Thumbtack
10. Yellowpages.com
11. Houzz
12. Porch
13. Nextdoor

Save to /mnt/user-data/outputs/citation-tracker.xlsx
```

### Prompt 3: Robots.txt AI Bot Check
```
Check the robots.txt file in the TVCT Website project. 

Verify that these AI crawlers are NOT blocked:
- ChatGPTbot
- OAI-SearchBot
- Anthropic-ai
- Claude-Web
- Googlebot

If they are blocked, or if robots.txt doesn't address them, update it to explicitly allow these bots while maintaining any existing rules.

Show me the before and after content.
```

### Prompt 4: NAP Consistency Audit
```
Audit NAP (Name, Address, Phone) consistency across the entire TVCT Website project.

The CORRECT NAP is:
- Name: The Valley Clean Team
- Address: 2784 Underwood Mountain Rd, Tuscumbia, AL 35674
- Phone: (256) 826-1100

Check these locations:
1. Footer component
2. Contact page
3. About page
4. All location hub pages
5. All neighborhood pages
6. JSON-LD schema markup in all pages

Report any inconsistencies found and fix them automatically. Show me a summary of what was changed.
```

---

## PHASE 1: Reviews & Tracking (Week 2)

### Prompt 5: Review Request Templates
```
Create SMS and email templates for review requests for The Valley Clean Team.

Create these 5 templates:
1. Initial SMS (under 160 characters) - sent 24 hours after service completion
2. Email template with subject line - sent same time as SMS
3. Follow-up SMS - sent 3 days later if no response
4. Response template for positive reviews (Google, Yelp, Facebook)
5. Response template for negative reviews (professional, empathetic, offers resolution)

Include the actual GBP review link placeholder: [REVIEW_LINK]

Tone: Warm, professional, not pushy. Emphasize we value their feedback.

Save as /docs/review-templates.md
```

### Prompt 6: Keyword Tracking List
```
Create a comprehensive keyword tracking list for The Valley Clean Team with 10 keywords per market.

Markets to cover:
1. Florence/Shoals (Florence, Muscle Shoals, Tuscumbia, Sheffield)
2. Huntsville/Madison
3. Athens/Limestone County
4. Mountain Brook/Birmingham
5. Nashville (future expansion)

For each market, include:
- [service] + [city] combinations (house cleaning, maid service, cleaning service)
- Emergency/same-day keywords
- Specialty services (move-out, deep clean, Airbnb)

Format as markdown table with columns:
| Keyword | Market | Priority (1-3) | Monthly Volume Est. | Current Ranking |

Leave Current Ranking blank for Todd to fill in.

Save as /docs/keyword-tracking.md
```

### Prompt 7: Monthly Ranking Spreadsheet
```
Create an Excel spreadsheet template for monthly rank tracking.

Structure:
- Sheet 1: "Overview" with summary metrics
- Sheet 2: "Florence/Shoals" 
- Sheet 3: "Huntsville"
- Sheet 4: "Athens"
- Sheet 5: "Mountain Brook"
- Sheet 6: "Nashville"

Each market sheet should have columns:
- Keyword
- Jan 2026 Rank
- Feb 2026 Rank
- Mar 2026 Rank
- (continue for 12 months)
- Trend (formula to show improvement/decline)

Pre-populate keywords from the keyword tracking list.

Save to /mnt/user-data/outputs/rank-tracking-2026.xlsx
```

---

## PHASE 2: Citations & Local Links (Weeks 3-4)

### Prompt 8: Partnership Pitch Emails
```
Create 3 email templates for partnership outreach for The Valley Clean Team.

Template 1: Real Estate Agent Partnership
- Pitch: We clean homes before listings go live and after closings
- Benefits: Faster sales, better photos, happy buyers
- Include specific service details and pricing structure

Template 2: Property Manager Partnership
- Pitch: Recurring cleaning for rental turnovers
- Benefits: Consistent quality, priority scheduling, bulk pricing
- Include turnaround time guarantees

Template 3: Local Business Cross-Promotion
- Pitch: Mutual referral partnership
- Benefits: Extended reach, trusted recommendations
- Include how referral tracking would work

Each email should:
- Have a compelling subject line
- Be under 200 words
- Include clear CTA
- Sound personal, not templated

Save as /docs/partnership-emails.md
```

### Prompt 9: Local Guide Content (Linkable Asset)
```
Create a comprehensive local guide: "The Complete Guide to Home Cleaning in the Shoals"

This should be 2000+ words of highly linkable content designed to earn backlinks from local blogs and news sites.

Structure:
1. Introduction to cleaning challenges in the Shoals area
   - High humidity and mold concerns
   - Red clay and seasonal dirt
   - Older homes with specific needs

2. Seasonal Cleaning Guide for North Alabama
   - Spring cleaning checklist
   - Summer humidity management
   - Fall preparation
   - Winter deep clean

3. How Much Does House Cleaning Cost in Florence/Muscle Shoals?
   - Price ranges by service type
   - Factors that affect pricing
   - What's included in different service levels

4. How to Choose a Cleaning Service in the Shoals
   - Questions to ask
   - Red flags to avoid
   - What to expect from professionals

5. DIY vs Professional: When to Call for Help
   - Tasks better left to pros
   - Cost-benefit analysis

6. Frequently Asked Questions

Include internal links to:
- Service pages (deep cleaning, move-out, recurring)
- Location pages (Florence, Muscle Shoals, Tuscumbia, Sheffield)

This is our primary link-building asset. Make it genuinely useful, not salesy.

Save as a new blog post in the content collection.
```

---

## PHASE 3: Strategic Page Creation (Month 2)

### Prompt 10: Small Town Pages Batch
```
Create neighborhood/small town pages for The Valley Clean Team following the existing neighborhood template pattern in the project.

Create pages for these underserved small towns (zero competition keywords):
1. Killen, AL (Florence hub child)
2. Rogersville, AL (Florence hub child)
3. Lexington, AL (Athens hub child)
4. St. Florian, AL (Muscle Shoals hub child)
5. Anderson, AL (Muscle Shoals hub child)

Each page requirements:
- 700+ words of unique content
- Mention specific local landmarks or characteristics
- Include zip codes served
- Link to parent hub page
- Link to 3-4 relevant service pages
- Include LocalBusiness schema with correct areaServed
- Follow existing SEO checklist in /docs/rules/seo-checklist.md

Before creating, read the existing neighborhood template pattern from one of the current pages.
```

### Prompt 11: County Pages
```
Create county-level landing pages for The Valley Clean Team.

Create pages for:
1. Lauderdale County, AL (parent: Florence)
2. Colbert County, AL (parent: Muscle Shoals)
3. Limestone County, AL (parent: Athens)

These are NEW hub-level pages targeting county-wide searches like "cleaning service Lauderdale County."

Each page should:
- 800+ words
- List all cities/towns we serve in that county
- Link to all child neighborhood pages
- Include LocalBusiness schema with areaServed as the county
- Strong CTA section
- FAQ section with county-specific questions
```

### Prompt 12: Missing Service Pages
```
Create these missing service pages across markets. Check which markets are missing each service and create the pages:

Services to create:
1. Deep Cleaning (check which markets don't have this)
2. Office Cleaning (likely missing from all markets)
3. Medical Office Cleaning (specialty - high value)
4. Move-Out Cleaning (check Florence specifically)
5. Post-Construction Cleaning (check which markets are missing)

For each page:
- 700-900 words
- Include Service schema markup
- FAQ section with 5-10 questions
- Clear pricing information (or "Get Quote" if variable)
- Link to relevant location pages
- Multiple CTAs
```

---

## PHASE 4: Content & Authority (Month 3)

### Prompt 13: Blog Content Batch
```
Create these 4 blog posts for The Valley Clean Team. Each should be 1000+ words with proper SEO optimization.

Post 1: "Spring Cleaning Checklist for Shoals Homeowners"
- Room-by-room checklist
- Local considerations (pollen, humidity)
- When to DIY vs hire pros
- Internal links to deep cleaning service

Post 2: "How to Prepare Your Home for a Professional Deep Clean"
- What to do before cleaners arrive
- What to expect during the clean
- Post-clean maintenance tips
- Internal links to recurring cleaning service

Post 3: "The Ultimate Move-Out Cleaning Guide for Alabama Renters"
- Security deposit recovery focus
- Checklist by room
- Landlord expectations
- Internal links to move-out service

Post 4: "Vacation Rental Cleaning Standards: What Hosts Need in 2026"
- Guest expectations
- Turnover timing
- Checklist for Airbnb/VRBO
- Internal links to vacation rental service

Each post should:
- Include BlogPosting schema
- Have optimized meta title and description
- Include relevant internal links
- Have a clear CTA
- Set draft: true initially
```

### Prompt 14: Press Release Draft
```
Draft a press release for The Valley Clean Team:

Headline: "Veteran-Owned, Women-Led Cleaning Company Celebrates Third Anniversary Serving North Alabama"

Include:
- Company founding story (November 2022)
- Veteran-owned and women-owned differentiators
- Service areas covered (Shoals, Huntsville, Athens, Birmingham, Nashville)
- Community involvement (if any - ask Todd or leave placeholder)
- Growth milestones
- Quote from owner (placeholder for Todd to personalize)
- Contact information
- Boilerplate "About The Valley Clean Team"

Follow AP style guidelines.
Format for submission to:
- Times Daily
- Shoals Insider
- North Alabama local news

Save as /docs/press-release-3year.md
```

---

## ONGOING: Weekly/Monthly Maintenance

### Prompt 15: GBP Post Generator (Reusable)
```
Generate 4 Google Business Profile posts for The Valley Clean Team for [MONTH].

Each post:
- 100-150 words
- Photo suggestion
- CTA at end
- Relevant seasonal hook

Topics to rotate:
- Cleaning tips
- Team/company spotlight
- Customer testimonial
- Service highlight
- Local community tie-in
- Before/after showcase

Save as /docs/gbp-posts-[MONTH].md
```

---

## Quick Reference: Task Assignment Summary

| Phase | You (Manual) | Claude Code | Total |
|-------|-------------|-------------|-------|
| Week 1 | 11 tasks | 4 tasks | 15 |
| Week 2 | 5 tasks | 3 tasks | 8 |
| Weeks 3-4 | 9 tasks | 2 tasks | 11 |
| Month 2 | 0 tasks | 10 tasks | 10 |
| Month 3 | 2 tasks | 6 tasks | 8 |
| **TOTAL** | **27 tasks** | **25 tasks** | **52** |

---

## Before Running Any Claude Code Prompts

Make sure Claude Code has access to:
1. The TVCT Website project directory
2. Existing templates and components
3. The SEO checklist at `/docs/rules/seo-checklist.md`
4. The CLAUDE.md project context file

Start each session with:
```
Read the CLAUDE.md file and /docs/rules/seo-checklist.md to understand the project context and SEO requirements before proceeding.
```
